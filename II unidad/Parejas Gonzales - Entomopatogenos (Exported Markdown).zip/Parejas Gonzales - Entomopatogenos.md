**UNIVERSIDAD NACIONAL TORIBIO RODRÍGUEZ DE MENDOZA DE AMAZONAS**

![null|Logotipo - UNTRM](img_0.jpg)​

**FACULTADA DE INGENIERÍA Y CIENCIAS AGRARIAS**

**ESCUELA PROFESIONAL DE AGRÓNOMIA**





**PROYECTO DE TESIS PARA OBTENER EL TITULO PROFESIONAL DE INGENIERIA AGRONOMA**







**ENTOMOPATÓGENOS PRESENTES EN ESPECIES DE CURCULIONIDAE (COLEOPTERA) ASOCIADOS A LOS PRINCIPALES CULTIVOS HOSPEDEROS DE AMAZONAS, PERÚ**





**Autora:  Parejas Gonzales, Jhodany**



**Asesor:  Dr. Leiva Espinoza, Santos Triunfo** 



**CHACHAPOYAS – PERÚ**

**2024**



1. Titulo

Entomopatógenos asociados a especies de Curculionidae (coleoptera) en plátano y caña de azúcar en Amazonas, Perú

1. Problema de investigación 

¿Cuáles son los entomopatógenos asociados a especies de Curculionidae (coleoptera) en piña y caña de azúcar en Amazonas, Perú?

1. Objetivos 
    1. Objetivo general 

Realizar la identificación de entomopatógenos de especies de Curculionidae asociados a los cultivos de plátano y caña de azúcar en Amazonas, Perú.

    1. Objetivo especifico
* _~~​*​**Realizar la identificación morfológica de especies de Curculionidae asociados a los cultivos de plátano y caña de azúcar en Amazonas, Perú .***​~~_
* _~~​*​**Realizar la identificación molecular de especies de Curculionidae asociados a los cultivos plátano y caña de azúcar, en Amazonas, Perú .***​~~_
* _~~​*​**Identificar morfológica y molecularmente entomopatógenos de especies de Curculionidae asociados a los cultivos de plátano y caña de azúcar en Amazonas, Perú .***​~~_
1. Antecedentes de la investigación

El cultivo de plátano (Musa × paradisiaca) es conocido es altamente producido en el mundo, especialmente en países como la India, que en 2022 produjo alrededor de 34 528 000 toneladas de plátanos. 

La caña de azúcar (Saccharum officinarum) es considerada 

Girón & Cardona-Duque, (2018), describen que la familia Curculionidae (Coleoptera: Curculionoidea), también llamados comúnmente "gorgojos o picudos" comprende uno de los grupos más grandes y diversos de insectos en el mundo.  Pertenecen a la gran familia Curculionoidea y está conformado por 19 subfamilias: Erirhininae, Dryophthorinae, Entiminae, Aterpinae, Gonipterinae, Rhythirrininae, Thecesterninae, Eugnominae, Hyperinae, Curculioninae, Cryptorhynchinae, Mesoptiliinae (= Magdalidinae), Molytinae, Baridinae, Lixinae, Conoderinae (= Zygopinae), Cossoninae, Scolytinae y Platypodinae (Marvaldi & Lanteri, 2005; Morrone, 2014). Según lo reportado por Oberprieler et al., (2007) la familia Curculionidae contiene alrededor de 62 000 especies descritas, siendo el número total probable de especies existentes aproximadamente 220 000.  

En el Perú la información sobre descripción de especies de Curculionidae es escasa (Legalov, 2019). Vos en 1959 describe 65 nuevas especies de Curculionidae, siendo unos de los principales estudios relacionados con especies de esta familia de curculiónidos. Mas especies han sido estudiadas y reportadas por otros investigadores como Erichson y Howden en los años 1847 y 2001 respectivamente. 

En cultivos de plátano, el complejo picudo está conformado por especies como *Cosmopilitus sordidus*, *Metamasius hemipterus*, *Metamasius hebetatus*, *Metamasius submaculatus* (Duque Gamboa, 2012)  **y *Rhynchophorus palmarum* (registrado en Colombia) (Sepúlveda-Cano & Rubio-Gómez, 2009), pertenecientes a la subfamilia Dryophthorinae. Siendo *C. sordidus* la especie mas distribuida en el mundo, seguida por *M. hebetatus* y *M. hemipterus* (Rubio & Acuña, 2006; Sepúlveda-Cano & Rubio-Gómez, 2009). Por otro lado *M. hemipterus* cuenta con 85 especies validas (Palmieri et al., 2022) y se ha descrito al gorgojo del tallo del plátano (*Odoiporus longicollis*), el cual se distribuye particularmente en países tropicales y subtropicales (Alagesan et al., 2019). Para el Perú se han registrado las dos especies de curculiónidos como plagas mas severas en este cultivo, dentro de las cuales tenemos al gorgojo negro (*C. sordidus)* y rayado del plátano (*M. hemipterus*) (Valladolid & Castillo Carrillo, 2001). 

En caña de azúcar, la especie más reportada como una plaga potencial es Metamasius hemipterus, la cual está distribuida ampliamente en América tropical y subtropical, siendo considerada una plaga de importancia económica en Ecuador y Bolivia (Castillo, 2009). En México se hizo un nuevo registro de especies de picudos por Ruiz-montiel & Illescas-riquelme, (2015) en el que se destaca a *Sphenophorus incurrens* Gyllenhal, *Apinocis subnudus* Buchanan y a especies reportadas por primera vez como *S.* incurrens y *A.* subnudus. Asi mismo Anderson, (2002) reporto 127 especies de curculiónidos en Costa Rica y 103 en Pánama pertenecientes a Cactophagus , Mesocordylus , Metamasius y Rhodobaenus (Coleoptera: Curculionidae). Indian et al., (1995)reportó a Diaprepes abbreviatus como única especie en Florida, Estados Unidos. 

1. Hipótesis 

Existen al menos dos entomopatógenos con capacidad de antagonista y con potencial de mortalidad (superior al 70%) sobre especies de Curculionidae en cultivos de arroz, plátano, piña y caña de azúcar, en Amazonas-Perú. 

    1. Hipótesis específicas
* _~~​*​**Existe al menos una especie de Curculionidae asociado a daños en cultivos de plátano y caña de azúcar.**  *​~~_
* _~~​*​**La identificación molecular permitirá confirmar y complementar la identificación morfológica de las especies de Curculionidae presentes, revelando especies críticas que no son detectables solo con métodos morfológicos.** *​~~_
* _~~​*​**Al menos una especie del género Beauveria se encuentra en condición de entomopatógeno de especies de Curculionidaes en cultivos de plátano y caña de azúcar.** *​~~_
1. Metodología 
    1. Población, muestra y muestreo
        1. Población 

La población está definida por el número total de unidades productivas de cultivo de plátano y por el número total de unidades productivas de cultivo de caña de azúcar. Según el último Censo Nacional Agropecuario realizado en 2012 existe un total de 2947 unidades productivas de caña de azúcar en Amazonas que incluye caña de azúcar para alcohol, caña de azúcar para azúcar y caña de azúcar para fruta. Así mismo, se detalla que existe un total de 1432 unidades productivas de caña de azúcar en Amazonas. 

        1. Muestra 

Sera determinada mediante una tabla dinámica que permite incluir el tamaño de la población objetivo (Unidades productivas de plátano y caña de azúcar), calculando automáticamente el tamaño de muestra con 10% de error y 95 % de probabilidad.  Como lo indica la tabla que se describe a continuación ([Table 1](?tab=t.0#bookmark=id.25k5oq3opi59)) 














| CULTIVO                      |                              | Caña de azúcar               | Plátano                       |
|------------------------------|------------------------------|------------------------------|-------------------------------|
| Tamaño de Población objetivo | N                            | 2947                         | 1432                          |
| Probabilidad                 | P                            | 0.5                          | 0.5                           |
| Probabilidad                 | Q                            | 0.5                          | 0.5                           |
| Error                        | d                            | 0.05                         | 0.1                           |
| **Tamaño de muestra**        | **n**                        | **352**                      | **94**                        |




: **Table 1:** {#tbl:id.25k5oq3opi59}

El tamaño de la muestra será determinado mediante la siguiente formula: 

![null|null](img_1.png)​ 

De esta manera encontramos que el tamaño de nuestra muestra será igual a 352 y 94 para cultivo de caña de azúcar y plátano respectivamente([Figure 1](?tab=t.0#bookmark=id.n2nrj0oplugb))

![Proceso de germinación del trigo, fotos tomadas con estereoscopio.](img_2.png){#fig:id.n2nrj0oplugb}



        1. Muestreo

El muestreo se definirá en base a la cantidad de unidades productoras de plátano y caña de azúcar en las diferentes provincias de Amazonas. De las cuales se definirá el lugar en donde se realizará la búsqueda directa de muestras (especies de Curculionidae) para la respectiva identificación morfológica y molecular.   

    1. Variables de estudio 
* _~~​*​**Especies de Curculionidae en cultivo de plátano.** *​~~_
* _~~​*​**Especies de Curculionidae en cultivos de caña de azúcar.** *​~~_
* _~~​*​**Especies de entomopatógenos asociados a especies de Curculiuonidae.** *​~~ _Métodos 
        1. Recolección de muestras 

Las muestras de insectos serán recolectadas de los cultivos de plátano y caña de azúcar mediante búsqueda visual directa y recolección manual, las cuales serán llevas a laboratorio para realizar las actividades pertinentes a la identificación molecular y morfológica. 

        1. Identificación morfológica. 

Se realizara la identificación morfológica siguiendo la metodología propuesta por propuesta por (Ren et al., 2024), que consiste en realizar mediciones, utilizando un micrómetro para medir la longitud estándar de estructuras principales del insecto como el margen anterior del tórax, el ápice de los élitros, longitud pronotal, longitud élitral, ancho élitral y ancho rostral [[1,2]](https://www.zotero.org/google-docs/?Qx4a8o). 

        1. Identificación molecular 

Se realizará la extracción de ADN de las especies seleccionadas para la identificación molecular siguiendo la metodología usada por (Ren et al., 2024). Que consiste en la extracción de ADN de todas las muestras mediante kits de sangre y tejido DNeasy, para la posterior amplificación por reacción en cadena de la polimerasa (PCR). 

    1. Cronograma 

CONTROl +  K para vincular


| ÉTAPAS                                    | MESES                                     | PERIODO                                   |                                            |
|-------------------------------------------|-------------------------------------------|-------------------------------------------|--------------------------------------------|
|                                           |                                           | INICIO                                    | TERMINO                                    |
| d. _~~​*​**Recolección de datos**​*​~~_   | Marzo                                     | 15 de marzo                               | 31 de marzo                                |
| e. _~~​*​**Análisis de resultados** *​~~_ | Junio – Diciembre                         | 1 de junio                                | 15 de diciembre                            |
| f. _~~​*​**Elaboración de informe**​*​~~_ | Enero – Junio                             | 10 enero                                  | 15 de junio                                |
| TOTAL                                     | 14 meses                                  |                                           |                                            |




: Table 2: {#tbl:id.1tk8mkep4xbj}

    1. Análisis de datos 

Este proyecto al ser clasificado por su naturaleza como investigación básica o pura y por su objetivo o propósito como investigación descriptiva no requiere de la aplicación de un diseño experimental y/o diseño estadístico. Sino más bien, el análisis de datos se realizará de acuerdo a las características cualitativas de las variables. 

1. Referencias bibliográficas

Alagesan, A., Padmanaban, B., Tharani, G., Jawahar, S., & Manivannan, S. (2019). An assessment of biological control of the banana pseudostem weevil Odoiporus longicollis (Olivier) by entomopathogenic fungi Beauveria bassiana. *Biocatalysis and Agricultural Biotechnology*, *20*, 101262. https://doi.org/https://doi.org/10.1016/j.bcab.2019.101262

Anderson, R. S. (2002). *Zootaxa 80*. *5326*(October).

Castillo, R. (2009). Centro De Investigación De La Caña De Azúcar Del Ecuador. *Centro De Investigación De La Caña De Azúcar Del Ecuador (Cincae)*. https://cincae.org/wp-content/uploads/2013/04/Año-11-No.-2.pdf

Duque Gamboa, D. N. (2012). Caracterización Molecular Del Complejo Picudo Del Plátano. *Universidad Del Valle*, 9–11.

Girón, J. C., & Cardona-Duque, J. (2018). Estado del conocimiento de los Curculionidae (Coleoptera: Curculionoidea) en Colombia. In *Escarabajos del neotrópico (Insecta: Coleoptera)* (Issue November 2018).

Indian, W., Antilles, L., Rico, P., Haven, M., County, G., Force, T., County, P., & Riehard, C. (1995). *A REVISION TO THE BIBLIOGRAPHY OF THE SUGARCANE ROOTSTALK BORER WEEVIL , DIAPREPES ABBREVIATUS ( COLEOPTERA : CURCULIONIDAE ) Bibliography : Diaprepes abbreviatus*. *78*(2), 364–377.

Legalov, A. A. (2019). Two new species of the genus Stenommatus Wollaston, 1873 (Coleoptera: Curculionidae: Dryophthorinae; Dryophthorini) from Peru. *Revista Peruana de Biologia*, *26*(4), 405–409. https://doi.org/10.15381/rpb.v26i4.17212

Marvaldi, A. E., & Lanteri, A. A. (2005). Key to higher taxa of South American weevils based on adult characters (Coleoptera, Curculionoidea). *Revista Chilena de Historia Natural*, *78*(1), 65–87. https://doi.org/10.4067/S0716-078X2005000100006

Morrone, J. J. (2014). Biodiversity of Curculionoidea (Coleoptera) in Mexico. *Revista Mexicana de Biodiversidad*, *85*(SUPPL.), 312–324. https://doi.org/10.7550/rmb.30038

Oberprieler, R. G., Marvaldi, A. E., & Anderson, R. S. (2007). *Weevils, weevils, weevils everywhere*. *1668*, 491–520. https://doi.org/https://doi.org/10.11646/zootaxa.1668.1.24

Palmieri, L., Lourdes Chamorro, M., & Sharma, P. P. (2022). Phylogenetic assessment of the Metamasius hemipterus species complex (Coleoptera, Curculionidae, Dryophthorinae). *Molecular Phylogenetics and Evolution*, *175*, 107589. https://doi.org/https://doi.org/10.1016/j.ympev.2022.107589

Ren, J., Ren, L., & Zhang, R. (2024). Revision of the Chinese Pachynotus Kollar & L. Redtenbacher, 1844 (Coleoptera, Curculionidae), with descriptions of two new species. *Zookeys*, *1197*, 153–169. https://doi.org/https://doi.org/10.3897/zookeys.1197.114969

Rubio, J. D., & Acuña, J. R. (2006). Anatomía comparada del tracto digestivo en imagos del complejo picudo (coleoptera: Curculionidae) asociados al cultivo del plátano. *Revista Colombiana de Entomologia*, *32*(1), 67–72.

Ruiz-montiel, A. C., & Illescas-riquelme, C. P. (2015). *Nuevos Registros de Picudos ( Coleoptera : Curculionidae ) Afectando Caña de Azúcar ( Saccharum officinarum L .) en Veracruz , México*. *June*. https://doi.org/10.3958/059.040.0216

Sepúlveda-Cano, P. A., & Rubio-Gómez, J. D. (2009). Especies de dryophthorinae (Coleoptera: Curculionidae) asociadas a plátano y banano (Musa spp.) en Colombia. *Acta Biologica Colombiana*, *14*(2), 49–72.

Valladolid, M., & Castillo Carrillo, P. S. (2001). El gorgojo rayado del platano (Metamasius hemipterus L.) (Coleoptera: Curculionidae) en Tumbes,Peru: Ciclo biologico en insectario. In *Revista Peruana de Entomología* (Vol. 42, pp. 69–72).

#  

[1. 	Ángel García, C.; Robledo Buriticá, J.; Castaño Zapata, J. Comparación de métodos de inoculación de Fusarium solani f. sp. passiflorae en plántulas de maracuyá (Passiflora edulis f. flavicarpa). *Rev. U.D.C.A Act. & Div. Cient.* **2018**, *21*, doi:10.31910/rudca.v21.n1.2018.659.](https://www.zotero.org/google-docs/?tKLPyE)

[2. 	Gazoulis, I.; Kanatas, P.; Antonopoulos, N. Cultural Practices and Mechanical Weed Control for the Management of a Low-Diversity Weed Community in Spinach. *Diversity* **2021**, *13*, 616, doi:10.3390/d13120616.](https://www.zotero.org/google-docs/?tKLPyE)



---

```Unknown element type at this position: UNSUPPORTED```

